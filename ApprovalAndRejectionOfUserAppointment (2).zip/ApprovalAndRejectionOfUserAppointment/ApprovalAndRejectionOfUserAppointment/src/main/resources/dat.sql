/*DROP TABLE IF EXISTS user_app;  

create table user_app(
USER_ID VARCHAR2(255 CHAR) NOT NULL,
USER_NAME VARCHAR2(255 CHAR),
USER_PASSWORD VARCHAR2(255 CHAR),
GENDER VARCHAR2(255 CHAR),
AGE NUMBER(3),
USER_ROLE VARCHAR2(255 CHAR),
CONTACT_NO NUMBER(19,2)
);
 */

/*update APPOINTMENT set status='rejected' where datetime>current_timestamp and status='pending';
*/
SELECT * FROM appointment;
 /*
 SELECT * FROM appointment WHERE datetime>current_timestamp;
 
insert into appointment(APPOINTMENTID,CENTERID,DATETIME,TESTID,USERID)values (800888,'21111','15-May-20 10:34:09.000','123123','100');

  insert into appointment(APPOINTMENTID,CENTERID,DATETIME,TESTID,USERID)values (899900,'21111','25-May-20 10:34:09.000','123123','100');

   insert into appointment(APPOINTMENTID,CENTERID,DATETIME,TESTID,USERID)values (888999,'21111','05-Jun-20 10:34:09.000','123123','100');
*/

 /*insert into appointment(APPOINTMENTID,CENTERID,DATETIME,TESTID,USERID)values (800888,'21111','15-May-20 10:34:09.000','123123','100');

  insert into appointment(APPOINTMENTID,CENTERID,DATETIME,TESTID,USERID)values (899900,'21111','25-May-20 10:34:09.000','123123','100');

   insert into appointment(APPOINTMENTID,CENTERID,DATETIME,TESTID,USERID)values (888999,'21111','05-Jun-20 10:34:09.000','123123','100');
*/
 
 /*insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (900000,'21111','05-JAN-20 10:34:09.000','approved','123123','111');
 
 insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (999000,'21111','08-JAN-20 10:34:09.000','rejected','123123','111');
                                          
insert into user_app (USERID,CONTACTNO,EMAILID,USERNAME,USERPASSWORD,USERROLE) values('111',1234567890,'l@gmail.com','lavi','lavi1234','user');        


insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (999999,'21111','04-JAN-20 10:34:09.000','pending','123123','111');
 
 insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (988888,'21111','06-JAN-20 10:34:09.000','pending','123123','111');
 
 insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (999900,'21111','04-JAN-20 10:34:09.000','pending','123123','100');
 
 insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (988880,'21111','06-JAN-20 10:34:09.000','pending','123123','100');
 
 
 insert into appointment(APPOINTMENTID,CENTERID,DATETIME,STATUS,TESTID,USERID)
 values (999888,'21111','14-JAN-20 10:34:09.000','pending','123123','111');
 
insert into test (TESTID,CENTERID,TESTNAME) values ('123123','21111','abi');
 
insert into diagnostic_center (CENTERID,ADDRESS,CENTERNAME,CONTACTNO) values ('21111','gujaini','asd',12345674);
  
select * from APPOINTMENT;*/
/*
insert into appointment(APPOINTMENT_ID,CENTER_ID,DATE_TIME,STATUS,TEST_ID,USER_ID)
 values (900000,'21111','05-JAN-20 10:34:09.000','approved','123123','111');
 
 insert into appointment(APPOINTMENT_ID,CENTER_ID,DATE_TIME,STATUS,TEST_ID,USER_ID)
 values (999000,'21111','08-JAN-20 10:34:09.000','rejected','123123','111');
                                          
insert into user_app (USER_ID,CONTACT_NO,EMAIL_ID,USER_NAME,USER_PASSWORD,USER_ROLE)
values('111',1234567890,'l@gmail.com','lavi','lavi1234','user');        


insert into appointment(APPOINTMENT_ID,CENTER_ID,DATE_TIME,STATUS,TEST_ID,USER_ID)
 values (999999,'21111','04-JAN-20 10:34:09.000','pending','123123','111');
 
 
insert into test (TEST_ID,CENTER_ID,TEST_NAME) values ('123123','21111','abi');
 
insert into diagnostic_center (CENTER_ID,ADDRESS,CENTER_NAME,CONTACT_NO) values 
  ('21111','gujaini','asd',12345674);
  */

/*select * from user_app u INNER JOIN appointment a on u.user_id=a.user_id inner join
  test t on a.test_id=t.test_id inner join diagnostic_center dc on t.center_id=dc.center_id;
  */
  
  
  