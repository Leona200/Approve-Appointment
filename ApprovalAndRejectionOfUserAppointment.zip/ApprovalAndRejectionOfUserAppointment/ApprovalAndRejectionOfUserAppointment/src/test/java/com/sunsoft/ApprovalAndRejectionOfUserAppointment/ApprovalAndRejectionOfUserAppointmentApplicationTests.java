package com.sunsoft.ApprovalAndRejectionOfUserAppointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApprovalAndRejectionOfUserAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
